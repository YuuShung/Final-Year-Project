﻿using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Identity;
using SixLabors.ImageSharp;
using SixLabors.ImageSharp.Processing;
using System.Security.Claims;
using System.Text.RegularExpressions;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace WebApplication1
{
    public class Helper(IWebHostEnvironment en,
                    IHttpContextAccessor ct)
    {
        // ------------------------------------------------------------------------
        // Photo Upload
        // ------------------------------------------------------------------------

        public string ValidatePhoto(IFormFile f)
        {
            var reType = new Regex(@"^image\/(jpeg|png)$", RegexOptions.IgnoreCase);
            var reName = new Regex(@"^.+\.(jpeg|jpg|png)$", RegexOptions.IgnoreCase);

            if (!reType.IsMatch(f.ContentType) || !reName.IsMatch(f.FileName))
            {
                return "Only JPG and PNG photo is allowed.";
            }
            else if (f.Length > 1 * 1024 * 1024)
            {
                return "Photo size cannot more than 1MB.";
            }

            return "";
        }

        public string SavePhoto(IFormFile f, string folder)
        {
            var file = Guid.NewGuid().ToString("n") + ".jpg";
            var path = Path.Combine(en.WebRootPath, folder, file);

            var options = new ResizeOptions
            {
                Size = new(200, 200),
                Mode = ResizeMode.Crop,
            };

            using var stream = f.OpenReadStream();
            using var img = Image.Load(stream);
            img.Mutate(x => x.Resize(options));
            img.Save(path);

            return file;
        }

        public void DeletePhoto(string file, string folder)
        {
            file = Path.GetFileName(file);
            var path = Path.Combine(en.WebRootPath, folder, file);
            File.Delete(path);
        }

        // ------------------------------------------------------------------------
        // Security Helper Functions
        // ------------------------------------------------------------------------

        private readonly PasswordHasher<object> ph = new();

        public string HashPassword(string password)
        {
            return ph.HashPassword(0, password);
        }

        public bool VerifyPassword(string hash, string password)
        {
            return ph.VerifyHashedPassword(0, hash, password)
                   == PasswordVerificationResult.Success;
        }

        public async Task SignIn(string email, string role, int userId, bool rememberMe)
        {
            // (1) Claims
            List<Claim> claims =
            [
                new Claim(ClaimTypes.Name, email),
        new Claim(ClaimTypes.Role, role),
        new Claim("UserId", userId.ToString()) // ✅ CRITICAL FIX
            ];

            ClaimsIdentity identity = new(claims, "Cookies");
            ClaimsPrincipal principal = new(identity);

            // (2) Remember me
            AuthenticationProperties properties = new()
            {
                IsPersistent = rememberMe,
            };

            // (3) Sign in
            await ct.HttpContext!.SignInAsync(principal, properties);
        }

        public void SignOut()
        {
            // Sign out
            ct.HttpContext!.SignOutAsync();
        }

        public string RandomPassword()
        {
            string s = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ";
            string password = "";

            Random r = new();

            for (int i = 1; i <= 10; i++)
            {
                password += s[r.Next(s.Length)];
            }

            return password;
        }
    }
}
