﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace WebApplication1.Models;

#nullable disable warnings
public class DB(DbContextOptions<DB> options) : DbContext(options)
{
    // Tables
    public DbSet<User> Users { get; set; }
    public DbSet<Admin> Admins { get; set; }
    public DbSet<Member> Members { get; set; }
    public DbSet<Interaction> Interactions { get; set; }
    public DbSet<TrustScore> TrustScores { get; set; }
    public DbSet<TrustModel> TrustModels { get; set; }
    public DbSet<AuthenticationLog> AuthenticationLogs { get; set; }
    public DbSet<LoginHistory> LoginHistories { get; set; }
    public DbSet<EvaluationResult> EvaluationResults { get; set; }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Interaction>()
            .HasOne(i => i.Sender)
            .WithMany(u => u.SentInteractions)
            .HasForeignKey(i => i.SenderId)
            .OnDelete(DeleteBehavior.Restrict);

        modelBuilder.Entity<Interaction>()
            .HasOne(i => i.Receiver)
            .WithMany(u => u.ReceivedInteractions)
            .HasForeignKey(i => i.ReceiverId)
            .OnDelete(DeleteBehavior.Restrict);

        modelBuilder.Entity<TrustModel>().HasData(

    new TrustModel
    {
        TrustModelId = 1,
        ModelName = "Reputation Model",
        Description = "Based on user interaction history"
    },

    new TrustModel
    {
        TrustModelId = 2,
        ModelName = "Zero Trust Model",
        Description = "Never trust, always verify"
    },

    new TrustModel
    {
        TrustModelId = 3,
        ModelName = "Blockchain Model",
        Description = "Tamper-proof trust evaluation"
    }
);
        modelBuilder.Entity<User>()
        .HasDiscriminator<string>("Discriminator")
        .HasValue<Admin>("Admin")
        .HasValue<Member>("Member");

        modelBuilder.Entity<User>().HasData(
            new User { UserId = 1, Name = "Jennie Kim", Email = "a1@gmail.com", Hash = "AQAAAAIAAYagAAAAEGyBGBzs6LQiyNF3QVuXc6Cz0yVIGikGDI6GdsXMFG6eDzkN0617JG54Tz/Zp/V35g==" },
            new User { UserId = 2, Name = "Kim Ji-Soo", Email = "a2@gmail.com", Hash = "AQAAAAIAAYagAAAAEGyBGBzs6LQiyNF3QVuXc6Cz0yVIGikGDI6GdsXMFG6eDzkN0617JG54Tz/Zp/V35g==" },
            new User { UserId = 3, Name = "Lalisa", Email = "m1@gmail.com", Hash = "AQAAAAIAAYagAAAAEGyBGBzs6LQiyNF3QVuXc6Cz0yVIGikGDI6GdsXMFG6eDzkN0617JG54Tz/Zp/V35g==" },
            new User { UserId = 4, Name = "Roseanne", Email = "m2@gmail.com", Hash = "AQAAAAIAAYagAAAAEGyBGBzs6LQiyNF3QVuXc6Cz0yVIGikGDI6GdsXMFG6eDzkN0617JG54Tz/Zp/V35g==" }
        );
    }
}

// User Entity
public class User
{
    [Key]
    public int UserId { get; set; }

    [StringLength(50)]
    public string Name { get; set; }

    [Required, MaxLength(100)]
    public string Email { get; set; }

    [MaxLength(100)]
    public string Hash { get; set; }

    
    //public string Role => GetType().Name;

    // Navigation
    public ICollection<Interaction> SentInteractions { get; set; }
    public ICollection<Interaction> ReceivedInteractions { get; set; }
    public ICollection<LoginHistory> LoginHistories { get; set; }
    public ICollection<TrustScore> TrustScores { get; set; }
    public ICollection<AuthenticationLog> AuthenticationLogs { get; set; }
}

public class Admin : User
{

}

public class Member : User
{
    [MaxLength(100)]
    public string? PhotoURL { get; set; }
}

public class Interaction
{
    [Key]
    public int InteractionId { get; set; }
    [ForeignKey("Sender")]
    public int SenderId { get; set; }
    [ForeignKey("Receiver")]
    public int ReceiverId { get; set; }

    public string Type { get; set; }

    public DateTime Timestamp { get; set; } = DateTime.Now;

    public bool IsSuccessful { get; set; }

    public User Sender { get; set; }
    
    public User Receiver { get; set; }
}

// Trust Model Entity
public class TrustModel
{
    [Key]
    public int TrustModelId { get; set; }

    public string ModelName { get; set; }

    public string Description { get; set; }

    public ICollection<TrustScore> TrustScores { get; set; }
}

public class TrustScore
{
    [Key]
    public int TrustId { get; set; }

    public int UserId { get; set; }

    public int TrustModelId { get; set; }

    public double Score { get; set; }

    public DateTime LastUpdated { get; set; } = DateTime.Now;

    public User User { get; set; }

    public TrustModel TrustModel { get; set; }
}

public class AuthenticationLog
{
    [Key]
    public int LogId { get; set; }

    public int UserId { get; set; }

    public DateTime Timestamp { get; set; } = DateTime.Now;

    public string EventType { get; set; }

    public User User { get; set; }
}

public class LoginHistory
{
    [Key]
    public int LoginID { get; set; }

    public int UserID { get; set; }

    public DateTime LoginTime { get; set; }

    public bool IsSuccessful { get; set; }

    public string IPAddress { get; set; }

    public string DeviceInfo { get; set; }
}

public class EvaluationResult
{
    [Key]
    public int ResultID { get; set; }

    public int UserID { get; set; }

    public double ReputationAccuracy { get; set; }

    public double ZeroTrustAccuracy { get; set; }

    public double BlockchainIntegrity { get; set; }

    public double OverallTrustScore { get; set; }

    public DateTime EvaluationDate { get; set; }
}

