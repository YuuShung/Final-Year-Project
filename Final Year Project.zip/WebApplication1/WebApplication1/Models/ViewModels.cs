﻿using Microsoft.AspNetCore.Mvc;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace WebApplication1.Models;

#nullable disable warnings

// ---------------- VIEW MODELS ----------------

public class LoginVM
{
    [EmailAddress]
    [StringLength(100)]
    public string Email { get; set; }

    [StringLength(100, MinimumLength = 6)]
    [DataType(DataType.Password)]
    public string Password { get; set; }

    public bool RememberMe { get; set; }
}

public class RegisterVM
{
    [StringLength(100)]
    [EmailAddress]
    [Remote("CheckEmail", "Account", ErrorMessage = "Email already exists.")]
    public string Email { get; set; }

    [StringLength(100, MinimumLength = 6)]
    [DataType(DataType.Password)]
    public string Password { get; set; }

    [StringLength(100, MinimumLength = 6)]
    [Compare("Password")]
    [DataType(DataType.Password)]
    [DisplayName("Confirm Password")]
    public string Confirm { get; set; }

    [StringLength(100)]
    public string Name { get; set; }

    public IFormFile Photo { get; set; }
}

public class UpdatePasswordVM
{
    [StringLength(100, MinimumLength = 6)]
    [DataType(DataType.Password)]
    [DisplayName("Current Password")]
    public string Current { get; set; }

    [StringLength(100, MinimumLength = 6)]
    [DataType(DataType.Password)]
    [DisplayName("New Password")]
    public string New { get; set; }

    [StringLength(100, MinimumLength = 6)]
    [Compare("New")]
    [DataType(DataType.Password)]
    [DisplayName("Confirm Password")]
    public string Confirm { get; set; }
}

public class UpdateProfileVM
{
    public string? Email { get; set; }

    [StringLength(100)]
    public string Name { get; set; }

    public string? PhotoURL { get; set; }

    public IFormFile? Photo { get; set; }
}

public class ResetPasswordVM
{
    [StringLength(100)]
    [EmailAddress]
    public string Email { get; set; }
}

public class TrustScoreChartVM
{
    public int Step { get; set; }
    public double Reputation { get; set; }
    public double ZeroTrust { get; set; }
    public double Blockchain { get; set; }
    public DateTime Date { get; set; }
    public double Score { get; set; }
    public string ModelName { get; set; }
}

public class AdminDashboardVM
{
    public int TotalUsers { get; set; }
    public int HighRiskUsers { get; set; }
    public double AverageTrustScore { get; set; }
    public int TotalLoginsToday { get; set; }

    public List<LoginHistory> RecentLogins { get; set; }
    public List<TrustScore> LatestTrustScores { get; set; }
}

public class ModelRankingVM
{
    public string Model { get; set; }
    public double Score { get; set; }
}