﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using WebApplication1.Helpers;
using static Microsoft.EntityFrameworkCore.DbLoggerCategory;

namespace WebApplication1.Controllers
{
    public class AdminController : Controller
    {
        private readonly DB _db;
        private readonly Helper _hp;
        private readonly TrustService _trustService;

        public AdminController(DB db, Helper hp, TrustService trustService)
        {
            _db = db;
            _hp = hp;
            _trustService = trustService;
        }

        public IActionResult AdminLogin()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> AdminLogin(string email, string password)
        {
            var admin = _db.Users
                .OfType<Admin>()
                .FirstOrDefault(x => x.Email == email);

            if (admin == null || !_hp.VerifyPassword(admin.Hash, password))
            {
                ViewBag.Error = "Invalid admin login";
                return View();
            }

            await _hp.SignIn(admin.Email, "Admin", admin.UserId, false);

            return RedirectToAction("Dashboard");
        }

        [Authorize(Roles = "Admin")]
        public IActionResult Dashboard()
        {
            var users = _db.Users
                .Include(u => u.TrustScores)
                .ToList();

            // Get latest trust score per user
            var latestScores = users
                .Select(u => u.TrustScores
                    .OrderByDescending(t => t.LastUpdated)
                    .FirstOrDefault())
                .Where(t => t != null)
                .Select(t => t!)
                .ToList();

            var vm = new AdminDashboardVM
            {
                TotalUsers = users.Count,

                TotalLoginsToday = _db.LoginHistories
                    .Count(l => l.LoginTime.Date == DateTime.Today),

                HighRiskUsers = latestScores
                    .Count(t => TrustHelper.GetRisk(t.Score) == "High Risk"),

                AverageTrustScore = latestScores.Any()
                    ? latestScores.Average(t => t.Score)
                    : 0,

                RecentLogins = _db.LoginHistories
                    .OrderByDescending(l => l.LoginTime)
                    .Take(10)
                    .ToList(),

                LatestTrustScores = latestScores
            };

            return View(vm);
        }

        [Authorize(Roles = "Admin")]
        public IActionResult Logs(int? userId, int page = 1)
        {
            int pageSize = 10;

            ViewBag.Users = _db.Users
                .Where(u => !(u is Admin))
                .ToList();

            ViewBag.SelectedUserId = userId;

            var query = _db.AuthenticationLogs.AsQueryable();

            if (userId.HasValue)
            {
                query = query.Where(l => l.UserId == userId.Value);
            }

            int totalRecords = query.Count();

            var data = query
                .OrderByDescending(l => l.Timestamp)
                .Skip((page - 1) * pageSize)
                .Take(pageSize)
                .ToList();

            ViewBag.CurrentPage = page;
            ViewBag.TotalPages = (int)Math.Ceiling((double)totalRecords / 10);

            return View(data);
        }

        public IActionResult Logout()
        {
            _hp.SignOut();
            return RedirectToAction("Index", "Home");
        }

        [Authorize(Roles = "Admin")]
        public IActionResult ManageUsers()
        {
            var users = _db.Users
                .Include(u => u.TrustScores)
                .ToList();

            return View(users);
        }

        public IActionResult AdminDetails(int id)
        {
            var user = _db.Users
                .Include(u => u.TrustScores)
                    .ThenInclude(t => t.TrustModel)
                .FirstOrDefault(u => u.UserId == id);

            if (user == null)
                return NotFound();

            return View(user);
        }

        [Authorize(Roles = "Admin")]
        public IActionResult EvaluationSummary(int? userId, DateTime? selectedDate, int page = 1)
        {
            // ================================
            // STEP 1: Get Member IDs ONLY
            // ================================
            var memberIds = _db.Users
                .OfType<Member>()
                .Select(m => m.UserId)
                .ToList();

            // ================================
            // STEP 2: Base Query (Members Only)
            // ================================
            var query = _db.EvaluationResults
                .Where(e => memberIds.Contains(e.UserID))
                .AsQueryable();

            // Optional filters
            if (userId.HasValue)
            {
                query = query.Where(e => e.UserID == userId.Value);
            }

            if (selectedDate.HasValue)
            {
                query = query.Where(e => e.EvaluationDate.Date == selectedDate.Value.Date);
            }

            // ================================
            // STEP 3: Pagination (TABLE DATA)
            // ================================
            int pageSize = 5;

            var totalRecords = query.Count();

            var data = query
                .OrderByDescending(e => e.EvaluationDate)
                .Skip((page - 1) * pageSize)
                .Take(pageSize)
                .ToList();

            // ================================
            // STEP 4: ANALYSIS (LATEST PER MEMBER)
            // ================================
            var allData = query
                .GroupBy(e => e.UserID)
                .Select(g => g.OrderByDescending(e => e.EvaluationDate).First())
                .ToList();

            // ================================
            // STEP 5: CORRECT AVERAGE CALCULATION
            // ================================
            double avgRep = allData.Any() ? allData.Average(x => x.ReputationAccuracy) : 0;
            double avgZero = allData.Any() ? allData.Average(x => x.ZeroTrustAccuracy) : 0;
            double avgBlock = allData.Any() ? allData.Average(x => x.BlockchainIntegrity) : 0;

            // Store in ViewBag (used by both pie chart + ranking)
            ViewBag.AvgReputation = avgRep;
            ViewBag.AvgZeroTrust = avgZero;
            ViewBag.AvgBlockchain = avgBlock;

            // ================================
            // STEP 6: RANKING (USE SAME VALUES)
            // ================================
            var ranking = new List<ModelRankingVM>
    {
        new ModelRankingVM { Model = "Reputation", Score = avgRep },
        new ModelRankingVM { Model = "Zero Trust", Score = avgZero },
        new ModelRankingVM { Model = "Blockchain", Score = avgBlock }
    }
            .OrderByDescending(x => x.Score)
            .ToList();

            ViewBag.Ranking = ranking;

            // ================================
            // STEP 7: VERDICT
            // ================================
            var best = ranking.First();

            bool isClose = ranking.Count > 1 &&
                           Math.Abs(ranking[0].Score - ranking[1].Score) < 3;

            string verdict = isClose
                ? $"Both {ranking[0].Model} and {ranking[1].Model} models perform similarly and are recommended."
                : $"{best.Model} model is recommended due to highest average performance.";

            ViewBag.Verdict = verdict;

            // ================================
            // STEP 8: REASON
            // ================================
            string reason = best.Model switch
            {
                "Blockchain" => "It ensures strong data integrity and resistance to tampering.",
                "Zero Trust" => "It enforces strict access control and continuous verification.",
                _ => "It evaluates trust effectively based on user behaviour and reputation."
            };

            ViewBag.Reason = reason;

            // ================================
            // STEP 9: VIEW DATA
            // ================================
            ViewBag.Users = _db.Users.OfType<Member>().ToList();
            ViewBag.SelectedUserId = userId;
            ViewBag.SelectedDate = selectedDate?.ToString("yyyy-MM-dd");

            ViewBag.CurrentPage = page;
            ViewBag.TotalPages = (int)Math.Ceiling((double)totalRecords / pageSize);

            return View(data);
        }

        public IActionResult ComparativeTrend(int? userId)
        {
            ViewBag.Users = _db.Users
                .Where(u => !(u is Admin))
                .ToList();

            ViewBag.SelectedUserId = userId;

            if (!userId.HasValue)
            {
                ViewBag.ChartData = "[]"; 
                return View();
            }

            var data = _db.TrustScores
                .Where(t => t.UserId == userId)
                .OrderBy(t => t.LastUpdated)
                .ToList()
                .GroupBy(t => t.LastUpdated.Date)
                .Select(g => new
                {
                    date = g.Key.ToString("yyyy-MM-dd"),

                    reputation = g.Where(x => x.TrustModelId == 1)
                                  .OrderByDescending(x => x.LastUpdated)
                                  .Select(x => x.Score)
                                  .FirstOrDefault(),

                    zeroTrust = g.Where(x => x.TrustModelId == 2)
                                 .OrderByDescending(x => x.LastUpdated)
                                 .Select(x => x.Score)
                                 .FirstOrDefault(),

                    blockchain = g.Where(x => x.TrustModelId == 3)
                                  .OrderByDescending(x => x.LastUpdated)
                                  .Select(x => x.Score)
                                  .FirstOrDefault()
                })
                .Where(x => x.reputation > 0 || x.zeroTrust > 0 || x.blockchain > 0)
                .ToList();

            ViewBag.ChartData = System.Text.Json.JsonSerializer.Serialize(data);

            return View();
        }
    }
}