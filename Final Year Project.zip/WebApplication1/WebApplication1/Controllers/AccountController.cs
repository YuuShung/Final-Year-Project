﻿using WebApplication1.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using WebApplication1;

namespace WebApplication1.Controllers;

public class AccountController(DB db, Helper hp, TrustService trustService) : Controller
{
    
    // GET: Account/checkEmail
    public bool CheckEmail(string email)
    {
        return !db.Users.Any(u => u.Email == email);
    }

    // GET: Account/Register
    public IActionResult Register()
    {
        return View();
    }

    // POST: Account/Register
    [HttpPost]
    public IActionResult Register(RegisterVM vm)
    {
        if (db.Users.Any(u => u.Email == vm.Email))
        {
            ModelState.AddModelError("Email", "Duplicated Email.");
        }

        if (vm.Photo != null)
        {
            var err = hp.ValidatePhoto(vm.Photo);
            if (err != "") ModelState.AddModelError("Photo", err);
        }

        if (ModelState.IsValid)
        {
            string? fileName = null;

            if (vm.Photo != null)
            {
                fileName = hp.SavePhoto(vm.Photo, "photos");
            }

            Member m = new()
            {
                Name = vm.Name,
                Email = vm.Email,
                Hash = hp.HashPassword(vm.Password),
                PhotoURL = fileName
            };

            db.Users.Add(m);
            db.SaveChanges();

            TempData["Info"] = "Register successfully. Please login.";
            return RedirectToAction("Login");
        }

        return View(vm);
    }

    // GET: Account/Login
    public IActionResult Login()
    {
        return View();
    }

    // POST: Account/Login
    [HttpPost]
    public async Task <IActionResult> Login(LoginVM vm, string? returnURL)
    {
        // Step 1: Find user by email only
        var u = db.Users.FirstOrDefault(u => u.Email == vm.Email);

        bool isSuccess = u != null && hp.VerifyPassword(u.Hash, vm.Password);

        if (!isSuccess)
        {
            ModelState.AddModelError("", "Invalid email or password.");
            return View(vm);
        }

        // -------- LOGGING --------
        if (u != null)
        {
            db.AuthenticationLogs.Add(new AuthenticationLog
            {
                UserId = u.UserId,
                EventType = isSuccess ? "Login Success" : "Login Failed"
            });

            db.Interactions.Add(new Interaction
            {
                SenderId = u.UserId,
                ReceiverId = u.UserId,
                Type = isSuccess ? "LoginSuccess" : "LoginFailed",
                IsSuccessful = isSuccess,
                Timestamp = DateTime.Now
            });

            db.LoginHistories.Add(new LoginHistory
            {
                UserID = u.UserId,
                LoginTime = DateTime.Now,
                IsSuccessful = isSuccess,
                IPAddress = HttpContext.Connection.RemoteIpAddress?.ToString() ?? "Unknown",
                DeviceInfo = Request.Headers["User-Agent"].ToString()
            });

            db.SaveChanges();

            if (isSuccess)
            {
                trustService.CalculateTrustForUser(u.UserId);
            }
        }

        // -------- SUCCESS --------
        if (isSuccess && u != null)
        {
            string role = u is Admin ? "Admin" : "Member";

            bool rememberMe = vm.RememberMe;

            await hp.SignIn(u.Email, "Member", u.UserId, rememberMe);

            if (!string.IsNullOrEmpty(returnURL))
                return Redirect(returnURL);

            return RedirectToAction("Index", "Home");
        }
        return View(vm);
    }

    // GET: Account/Profile
    [Authorize(Roles = "Member")]
    public IActionResult UpdateProfile()
    {
        var m = db.Members.FirstOrDefault(x => x.Email == User.Identity!.Name);
        if (m == null) return RedirectToAction("Index", "Home");

        var vm = new UpdateProfileVM
        {
            Email = m.Email,
            Name = m.Name,
            PhotoURL = m.PhotoURL,
        };

        return View(vm);
    }

    // POST: Account/UpdateProfile
    [Authorize(Roles = "Member")]
    [HttpPost]
    public IActionResult UpdateProfile(UpdateProfileVM vm)
    {
        var m = db.Members.FirstOrDefault(x => x.Email == User.Identity!.Name);
        if (m == null) return RedirectToAction("Index", "Home");

        if (vm.Photo != null)
        {
            var err = hp.ValidatePhoto(vm.Photo);
            if (err != "") ModelState.AddModelError("Photo", err);
        }

        if (ModelState.IsValid)
        {
            m.Name = vm.Name;

            if (!string.IsNullOrEmpty(m.PhotoURL))
            {
                hp.DeletePhoto(m.PhotoURL, "photos");
            }

            db.SaveChanges();

            TempData["Info"] = "Profile updated.";
            return RedirectToAction();
        }

        vm.Email = m.Email;
        vm.PhotoURL = m.PhotoURL;
        return View(vm);
    }

    // GET: Account/Logout
    public IActionResult Logout(string? returnURL)
    {
        hp.SignOut();

        return RedirectToAction("Index", "Home");
    }

    // GET: Account/AccessDenied
    public IActionResult AccessDenied(string? returnURL)
    {
        return View();
    }

    // GET: Account/UpdatePassword
    [Authorize]
    public IActionResult UpdatePassword()
    {
        return View();
    }

    // POST: Account/UpdatePassword
    [Authorize]
    [HttpPost]
    public IActionResult UpdatePassword(UpdatePasswordVM vm)
    {
        var u = db.Users.FirstOrDefault(x => x.Email == User.Identity!.Name);
        if (u == null) return RedirectToAction("Index", "Home");

        if (!hp.VerifyPassword(u.Hash, vm.Current))
        {
            ModelState.AddModelError("Current", "Current Password not matched.");
        }

        if (ModelState.IsValid)
        {
            u.Hash = hp.HashPassword(vm.New);
            db.SaveChanges();

            TempData["Info"] = "Password updated.";
            return RedirectToAction();
        }

        return View(vm);
    }

    // GET: Account/ResetPassword
    public IActionResult ResetPassword()
    {
        return View();
    }

    // POST: Account/ResetPassword
    [HttpPost]
    public IActionResult ResetPassword(ResetPasswordVM vm)
    {
        var u = db.Users.FirstOrDefault(x => x.Email == vm.Email);

        if (u == null)
        {
            ModelState.AddModelError("Email", "Email not found.");
        }

        if (ModelState.IsValid)
        {
            string password = hp.RandomPassword();

            u!.Hash = hp.HashPassword(password);
            db.SaveChanges();

            TempData["Info"] = $"Password reset. Check your email.";
            return RedirectToAction();
        }

        return View(vm);
    }
}