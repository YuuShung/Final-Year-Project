﻿namespace WebApplication1.Services;

public class TrustService
{
    private readonly DB _db;

    public TrustService(DB db)
    {
        _db = db;
    }

    public void CalculateTrustForUser(int userId)
    {
        var interactions = _db.Interactions
            .Where(i => i.SenderId == userId || i.ReceiverId == userId)
            .OrderBy(i => i.Timestamp)
            .ToList();

        if (!interactions.Any())
            return;

        int loginSuccess = interactions.Count(i => i.Type == "LoginSuccess");
        int loginFail = interactions.Count(i => i.Type == "LoginFailed");
        int txSuccess = interactions.Count(i => i.Type == "Success");
        int txFail = interactions.Count(i => i.Type == "Fail");

        double reputationScore =
            (loginSuccess * 5 + txSuccess * 15)
            - (loginFail * 5 + txFail * 10);

        reputationScore = Math.Clamp(reputationScore, 0, 100);

        double zeroTrustScore =
            100 - (loginFail * 20 + txFail * 30);

        zeroTrustScore = Math.Clamp(zeroTrustScore, 0, 100);

        double blockchainScore = 80;

        foreach (var interaction in interactions)
        {
            if (interaction.IsSuccessful)
                blockchainScore += 0.5;
            else
                blockchainScore -= 2;
        }

        blockchainScore = Math.Clamp(blockchainScore, 0, 100);

        double overallScore =
            (reputationScore + zeroTrustScore + blockchainScore) / 3;

        
        _db.EvaluationResults.Add(new EvaluationResult
        {
            UserID = userId,
            ReputationAccuracy = reputationScore,
            ZeroTrustAccuracy = zeroTrustScore,
            BlockchainIntegrity = blockchainScore,
            OverallTrustScore = overallScore,
            EvaluationDate = DateTime.Now
        });

        _db.TrustScores.AddRange(
            new TrustScore
            {
                UserId = userId,
                TrustModelId = 1,
                Score = reputationScore,
                LastUpdated = DateTime.Now
            },
            new TrustScore
            {
                UserId = userId,
                TrustModelId = 2,
                Score = zeroTrustScore,
                LastUpdated = DateTime.Now
            },
            new TrustScore
            {
                UserId = userId,
                TrustModelId = 3,
                Score = blockchainScore,
                LastUpdated = DateTime.Now
            }
        );

        _db.SaveChanges();
    }

    public List<TrustScoreChartVM> GetComparativeTrend(int userId)
    {
        var data = _db.TrustScores
            .Where(t => t.UserId == userId)
            .OrderBy(t => t.LastUpdated)
            .ToList()
            .GroupBy(t => t.LastUpdated.Date)
            .Select((group, index) => new TrustScoreChartVM
            {
                Step = index + 1,

                Reputation = group
                    .Where(x => x.TrustModelId == 1)
                    .Select(x => x.Score)
                    .FirstOrDefault(),

                ZeroTrust = group
                    .Where(x => x.TrustModelId == 2)
                    .Select(x => x.Score)
                    .FirstOrDefault(),

                Blockchain = group
                    .Where(x => x.TrustModelId == 3)
                    .Select(x => x.Score)
                    .FirstOrDefault()
            })
            .ToList();

        return data;
    }
}