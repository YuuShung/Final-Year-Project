﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;

namespace WebApplication1.Controllers
{
    [Authorize(Roles = "Member,Admin")]
    public class TrustController : Controller
    {
        private readonly DB _db;
        private readonly TrustService _trustService;

        public TrustController(DB db, TrustService trustService)
        {
            _db = db;
            _trustService = trustService;
        }

        private int? GetUserId()
        {
            var claim = User.FindFirst("UserId");

            if (claim == null)
                return null;

            if (int.TryParse(claim.Value, out int userId))
                return userId;

            return null;
        }

        private int GetValidUserId()
        {
            var userId = GetUserId();

            if (userId == null)
                throw new UnauthorizedAccessException("UserId claim missing");

            return userId.Value;
        }

        // USER: View own trust score

        public IActionResult MyTrust()
        {
            int userId = GetValidUserId();

            var trustScores = _db.TrustScores
                .Include(t => t.TrustModel)
                .Where(t => t.UserId == userId)
                .ToList();

            return View(trustScores);
        }

        // USER: Calculate own trust score
        public IActionResult CalculateMyTrust()
        {
            var userId = GetValidUserId();

            _trustService.CalculateTrustForUser(userId);

            return RedirectToAction("MyTrust");
        }

        // ADMIN / USER: View all trust scores
        public IActionResult Index()
        {
            var userId = GetValidUserId();

            var isAdmin = User.IsInRole("Admin");

            var query = _db.TrustScores
                .Include(t => t.User)
                .Include(t => t.TrustModel)
                .AsQueryable();

            if (!isAdmin)
            {
                // Member → only own data
                query = query.Where(t => t.UserId == userId);
            }
            // Admin → no filter (see all)

            var trustScores = query
                .OrderByDescending(t => t.LastUpdated)
                .ToList();

            return View(trustScores);
        }

        // USER: View trust details
        public IActionResult Details(int id)
        {
            var userId = GetValidUserId();

            var trust = _db.TrustScores
                .Include(t => t.User)
                .Include(t => t.TrustModel)
                .FirstOrDefault(t => t.TrustId == id);

            if (trust == null)
                return NotFound();

            // Member restriction
            if (User.IsInRole("Member") && trust.UserId != userId)
                return Forbid();

            return View(trust);
        }

        // USER: View trust history
        [Authorize(Roles = "Member")]
        public IActionResult History()
        {
            var userId = GetValidUserId();

            var history = _db.TrustScores
                .Include(t => t.TrustModel)
                .Where(t => t.UserId == userId)
                .OrderByDescending(t => t.LastUpdated)
                .ToList();

            return View(history);
        }

        // USER: View trust score trend
        [Authorize(Roles = "Member")]
        public IActionResult Trend(DateTime? startDate, DateTime? endDate)
        {
            var userId = GetValidUserId();

            var query = _db.TrustScores
        .Where(t => t.UserId == userId);

            if (startDate.HasValue)
            {
                query = query.Where(t => t.LastUpdated >= startDate.Value);
            }

            if (endDate.HasValue)
            {
                query = query.Where(t => t.LastUpdated <= endDate.Value);
            }

            var data = query
                .GroupBy(t => t.LastUpdated.Date)
                .Select(g => new TrustScoreChartVM
                {
                    Date = g.Key,
                    Reputation = g.Where(x => x.TrustModelId == 1).Select(x => x.Score).FirstOrDefault(),
                    ZeroTrust = g.Where(x => x.TrustModelId == 2).Select(x => x.Score).FirstOrDefault(),
                    Blockchain = g.Where(x => x.TrustModelId == 3).Select(x => x.Score).FirstOrDefault()
                })
                .OrderBy(x => x.Date)
                .ToList();

            ViewBag.StartDate = startDate?.ToString("yyyy-MM-dd");
            ViewBag.EndDate = endDate?.ToString("yyyy-MM-dd");

            return View(data);
        }

        [Authorize(Roles = "Member,Admin")]
        public IActionResult TrustChart()
        {
            int userId = GetValidUserId();
            var isAdmin = User.IsInRole("Admin");

            var query = _db.TrustScores.AsQueryable();

            if (!isAdmin)
            {
                // Member → only own data
                query = query.Where(t => t.UserId == userId);
            }

            var data = _db.TrustScores
                .OrderBy(t => t.LastUpdated)
                .ToList()
                .GroupBy(t => t.LastUpdated.Date) // or use Step logic
                .Select((group, index) => new TrustScoreChartVM
                {
                    Step = index + 1,

                    Reputation = group
                        .Where(x => x.TrustModelId == 1)
                        .Select(x => x.Score)
                        .FirstOrDefault(),

                    ZeroTrust = group
                        .Where(x => x.TrustModelId == 2)
                        .Select(x => x.Score)
                        .FirstOrDefault(),

                    Blockchain = group
                        .Where(x => x.TrustModelId == 3)
                        .Select(x => x.Score)
                        .FirstOrDefault()
                })
                .ToList();

            return View(data);
        }
    }
}