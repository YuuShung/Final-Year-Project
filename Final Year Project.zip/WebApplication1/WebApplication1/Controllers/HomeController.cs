﻿using Microsoft.AspNetCore.Mvc;
using System.Linq;

namespace WebApplication1.Controllers
{
    public class HomeController : Controller
    {
        private readonly DB _db;

        public HomeController(DB db)
        {
            _db = db;
        }

        public IActionResult Index()
        {
            var models = _db.TrustModels.ToList();
            return View(models);
        }
    }
}