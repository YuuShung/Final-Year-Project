﻿namespace WebApplication1.Helpers
{
    public static class TrustHelper
    {
        public static string GetRisk(double score)
        {
            if (score >= 80) return "Low Risk";
            if (score >= 50) return "Medium Risk";
            return "High Risk";
        }

        public static string GetModelName(int id)
        {
            return id switch
            {
                1 => "Blockchain",
                2 => "Zero Trust",
                3 => "Reputation",
                _ => "Unknown"
            };
        }
    }
}